# CPG_Webots_Nao_PhaseOs

This is the Central Pattern Generator simulation for NAO robot. Phase osscillator is used in each node. 
Swam Optimization is used for optimizing the parameters in the system.
All project is written in matlab for coordinating with Webots. 
